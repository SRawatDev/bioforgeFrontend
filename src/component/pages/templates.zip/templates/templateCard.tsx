import React, { useEffect, useRef } from 'react';
import './TemplateCard.css';

interface SocialLink {
  platform: string;
  username: string;
  icon: string;
  gradientFrom: string;
  gradientTo: string;
  borderColor: string;
  shadowColor: string;
}

interface TemplateCardProps {
  id: number;
  name: string;
  profession: string;
  description: string;
  profileImage: string;
  socialLinks: SocialLink[];
}

const TemplateCard: React.FC<TemplateCardProps> = ({
  name,
  profession,
  description,
  profileImage,
  socialLinks
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Enhanced mobile touch feedback
    const handleTouchStart = (e: TouchEvent) => {
      const target = e.target as HTMLElement;
      if (target.onclick || target.parentElement?.onclick) {
        target.style.opacity = '0.8';
        target.style.transform = 'scale(0.95)';
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      const target = e.target as HTMLElement;
      if (target.onclick || target.parentElement?.onclick) {
        setTimeout(() => {
          target.style.opacity = '1';
          target.style.transform = 'scale(1)';
        }, 200);
      }
    };

    // Add subtle parallax effect on mouse move
    const handleMouseMove = (e: MouseEvent) => {
      const container = containerRef.current;
      if (container) {
        const rect = container.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;
        
        container.style.transform = `perspective(1000px) rotateY(${(x - 0.5) * 5}deg) rotateX(${(y - 0.5) * -5}deg)`;
      }
    };

    const handleMouseLeave = () => {
      const container = containerRef.current;
      if (container) {
        container.style.transform = 'perspective(1000px) rotateY(0deg) rotateX(0deg)';
      }
    };

    document.addEventListener('touchstart', handleTouchStart);
    document.addEventListener('touchend', handleTouchEnd);
    
    const container = containerRef.current;
    if (container) {
      container.addEventListener('mousemove', handleMouseMove);
      container.addEventListener('mouseleave', handleMouseLeave);
    }

    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchend', handleTouchEnd);
      if (container) {
        container.removeEventListener('mousemove', handleMouseMove);
        container.removeEventListener('mouseleave', handleMouseLeave);
      }
    };
  }, []);

  const handleSocialClick = (platform: string, e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    // Enhanced social media click animation
    target.style.transform = 'scale(0.8) rotate(10deg)';
    target.style.filter = 'brightness(1.3)';
    
    setTimeout(() => {
      target.style.transform = 'translateY(-5px) scale(1.1) rotate(-5deg)';
      target.style.filter = 'brightness(1)';
    }, 200);

    // Handle social media navigation
    console.log(`Opening ${platform}`);
  };

  const getNavCards = () => {
    const navItems = [
      { icon: '🍹', title: 'Portfolio', text: 'My Work' },
      { icon: '📍', title: 'Contact', text: 'Get in Touch' },
      { icon: '🌿', title: 'About', text: 'My Story' },
      { icon: '🎧', title: 'Blog', text: 'Latest Posts' }
    ];

    return navItems.map((item, index) => (
      <div key={index} className={`nav-card nav-card-${index + 1}`}>
        <div className="card-icon">{item.icon}</div>
        <h3 className="card-title">{item.title}</h3>
        <p className="card-text">{item.text}</p>
      </div>
    ));
  };

  return (
    <div className="hydra-dashboard">
      {/* Floating Background Elements */}
      <div className="floating-bg floating-bg-1"></div>
      <div className="floating-bg floating-bg-2"></div>
      <div className="floating-bg floating-bg-3"></div>

      {/* Main Container */}
      <div className="main-container" ref={containerRef}>
        {/* Animated Background Pattern */}
        <div className="animated-bg-pattern"></div>

        {/* Header Section */}
        <div className="header-section">
          {/* Logo Container */}
          <div className="logo-container">
            <div className="logo-box">
              <img src={profileImage} alt={name} className="profile-image" />
            </div>
            {/* Glow Effect */}
            <div className="logo-glow"></div>
          </div>
          <h1 className="main-title">{name.split(' ')[0].toUpperCase()}</h1>
          <p className="subtitle">{profession}</p>
          <p className="description">{description}</p>
        </div>

        {/* Navigation Grid */}
        <div className="navigation-grid">
          {getNavCards()}
        </div>

        {/* Social Media Section */}
        <div className="social-section">
          <div className="social-icons">
            {socialLinks.slice(0, 4).map((link, index) => (
              <div
                key={index}
                className={`social-icon ${link.platform}-icon`}
                onClick={(e) => handleSocialClick(link.platform, e)}
              >
                <i className={link.icon}></i>
              </div>
            ))}
          </div>
          <div className="divider"></div>
          <p className="copyright">© 2024 {name.toUpperCase()}</p>
          <p className="tagline">Crafted with BioForge ✨</p>
        </div>
      </div>
    </div>
  );
};

export default TemplateCard;
