import React from "react";
import { useNavigate } from "react-router-dom";
import TemplateCard from "./templateCard";
import "./templates.css";

interface SocialLink {
  platform: string;
  username: string;
  icon: string;
  gradientFrom: string;
  gradientTo: string;
  borderColor: string;
  shadowColor: string;
}

interface TemplateData {
  id: number;
  name: string;
  profession: string;
  description: string;
  profileImage: string;
  socialLinks: SocialLink[];
}

const TemplateLanding: React.FC = () => {
  const navigate = useNavigate();

  const templateData: TemplateData[] = [
    {
      id: 1,
      name: "Vansh Kushwaha",
      profession: "Creative Designer",
      description:
        "Passionate about creating stunning visual experiences that inspire and engage audiences worldwide.",
      profileImage: "/assets/108723120.png",
      socialLinks: [
        {
          platform: "instagram",
          username: "@vanshkushwaha",
          icon: "fab fa-instagram",
          gradientFrom: "from-pink-500/20",
          gradientTo: "to-purple-500/20",
          borderColor: "border-pink-500/30",
          shadowColor: "rgba(236,72,153,0.3)",
        },
        {
          platform: "twitter",
          username: "@vanshkushwaha",
          icon: "fab fa-twitter",
          gradientFrom: "from-blue-500/20",
          gradientTo: "to-cyan-500/20",
          borderColor: "border-blue-500/30",
          shadowColor: "rgba(59,130,246,0.3)",
        },
        {
          platform: "youtube",
          username: "@vanshkushwaha",
          icon: "fab fa-youtube",
          gradientFrom: "from-red-500/20",
          gradientTo: "to-orange-500/20",
          borderColor: "border-red-500/30",
          shadowColor: "rgba(239,68,68,0.3)",
        },
        {
          platform: "linkedin",
          username: "Vansh Kushwaha",
          icon: "fab fa-linkedin-in",
          gradientFrom: "from-blue-600/20",
          gradientTo: "to-indigo-600/20",
          borderColor: "border-blue-600/30",
          shadowColor: "rgba(37,99,235,0.3)",
        },
      ],
    },
    {
      id: 2,
      name: "Alex Johnson",
      profession: "Full Stack Developer",
      description:
        "Building innovative web applications with modern technologies and clean, efficient code.",
      profileImage: "/assets/108723120.png",
      socialLinks: [
        {
          platform: "github",
          username: "@alexjohnson",
          icon: "fab fa-github",
          gradientFrom: "from-gray-700/20",
          gradientTo: "to-gray-900/20",
          borderColor: "border-gray-700/30",
          shadowColor: "rgba(75,85,99,0.3)",
        },
        {
          platform: "linkedin",
          username: "Alex Johnson",
          icon: "fab fa-linkedin-in",
          gradientFrom: "from-blue-600/20",
          gradientTo: "to-indigo-600/20",
          borderColor: "border-blue-600/30",
          shadowColor: "rgba(37,99,235,0.3)",
        },
        {
          platform: "twitter",
          username: "@alexjohnson",
          icon: "fab fa-twitter",
          gradientFrom: "from-blue-500/20",
          gradientTo: "to-cyan-500/20",
          borderColor: "border-blue-500/30",
          shadowColor: "rgba(59,130,246,0.3)",
        },
        {
          platform: "instagram",
          username: "@alexjohnson",
          icon: "fab fa-instagram",
          gradientFrom: "from-pink-500/20",
          gradientTo: "to-purple-500/20",
          borderColor: "border-pink-500/30",
          shadowColor: "rgba(236,72,153,0.3)",
        },
      ],
    },
    {
      id: 3,
      name: "Sarah Chen",
      profession: "UX/UI Designer",
      description:
        "Crafting user-centered designs that bridge the gap between functionality and beautiful aesthetics.",
      profileImage: "/assets/108723120.png",
      socialLinks: [
        {
          platform: "instagram",
          username: "@sarahchen",
          icon: "fab fa-instagram",
          gradientFrom: "from-pink-500/20",
          gradientTo: "to-purple-500/20",
          borderColor: "border-pink-500/30",
          shadowColor: "rgba(236,72,153,0.3)",
        },
        {
          platform: "linkedin",
          username: "Sarah Chen",
          icon: "fab fa-linkedin-in",
          gradientFrom: "from-blue-600/20",
          gradientTo: "to-indigo-600/20",
          borderColor: "border-blue-600/30",
          shadowColor: "rgba(37,99,235,0.3)",
        },
        {
          platform: "youtube",
          username: "@sarahchen",
          icon: "fab fa-youtube",
          gradientFrom: "from-red-500/20",
          gradientTo: "to-orange-500/20",
          borderColor: "border-red-500/30",
          shadowColor: "rgba(239,68,68,0.3)",
        },
        {
          platform: "facebook",
          username: "Sarah Chen",
          icon: "fab fa-facebook-f",
          gradientFrom: "from-blue-700/20",
          gradientTo: "to-blue-800/20",
          borderColor: "border-blue-700/30",
          shadowColor: "rgba(29,78,216,0.3)",
        },
      ],
    },
  ];

  const handleTemplateSelect = (templateId: number) => {
    // Navigate to template customization or preview
    navigate(`/dashboard/template/${templateId}`);
  };

  return (
    <div className="template-landing">
      <div className="template-header">
        <h1 className="template-title">Choose Your Template</h1>
        <p className="template-subtitle">
          Select a stunning template to showcase your digital identity
        </p>
      </div>

      <div className="templates-grid">
        {templateData.map((template) => (
          <div key={template.id} className="template-wrapper">
            <TemplateCard
              id={template.id}
              name={template.name}
              profession={template.profession}
              description={template.description}
              profileImage={template.profileImage}
              socialLinks={template.socialLinks}
            />
            <div className="template-actions">
              <button
                className="template-btn template-btn-primary"
                onClick={() => handleTemplateSelect(template.id)}
              >
                Use This Template
              </button>
              <button
                className="template-btn template-btn-secondary"
                onClick={() => navigate(`/preview/template/${template.id}`)}
              >
                Preview
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="template-footer">
        <p>More templates coming soon!</p>
        <button className="back-btn" onClick={() => navigate("/dashboard")}>
          ← Back to Dashboard
        </button>
      </div>
    </div>
  );
};

export default TemplateLanding;
